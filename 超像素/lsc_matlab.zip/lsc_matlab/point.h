#ifndef POINT
#define POINT

class point
{
public:
	int x,y;
	point(int X=0,int Y=0):x(X),y(Y){};
};

#endif